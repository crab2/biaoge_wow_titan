if BG.IsBlackListPlayer then return end
local AddonName, ns = ...

local LibBG = ns.LibBG
local L = ns.L

local NN = ns.NN
local RGB = ns.RGB
local RGB_16 = ns.RGB_16
local GetClassRGB = ns.GetClassRGB
local SetClassCFF = ns.SetClassCFF
local AddTexture = ns.AddTexture
local GetItemID = ns.GetItemID

local Maxb = ns.Maxb

local RealmID = GetRealmID()
local player = BG.playerName

BG.Init(function()
    BiaoGe.options.showAuctionLogFrame = BiaoGe.options.showAuctionLogFrame or 1
    BiaoGe.options.auctionLogChoose = BiaoGe.options.auctionLogChoose or 1
    BiaoGe.options.autoCreateBill = BiaoGe.options.autoCreateBill or 1
    BiaoGe.auctionTrade = nil
    BG.auctionTrade = {}
    local GetErrorItem

    BG.Once("showAuctionLogFrame", 260209, function()
        BiaoGe.options.showAuctionLogFrame = 1
    end)

    local function HighlightBiaoGeSameItems(itemID, link, self)
        local tbl = {}
        local FB = BG.FB1
        for b = 1, Maxb[FB] do
            for i = 1, BG.GetMaxi(FB, b) do
                local zb = BG.Frame[FB]["boss" .. b]["zhuangbei" .. i]
                local jine = BG.Frame[FB]["boss" .. b]["jine" .. i]
                if zb then
                    if itemID == GetItemID(zb:GetText()) then
                        tinsert(tbl, { zb = zb, jine = jine })
                    end
                end
            end
        end
        if #tbl > 1 then
            local frame
            for i, v in ipairs(tbl) do
                frame = BG.CreateHighlightFrame(self, nil, { 1, 0, 0, 0 }, 4)
            end
            local t = frame:CreateFontString()
            t:SetFont(BIAOGE_TEXT_FONT, 20, "OUTLINE")
            t:SetPoint("RIGHT", self, "RIGHT", -2, 0)
            t:SetTextColor(1, 0, 0)
            t:SetText(#tbl)
            BG.HighlightItemAuctionLog(link)
        end
        tbl = nil
    end

    local bt = CreateFrame("Button", nil, BG.MainFrame)
    do
        bt:SetPoint("LEFT", BG.ButtonMove, "RIGHT", BG.TopLeftButtonJianGe, 0)
        bt:SetNormalFontObject(BG.FontGreen15)
        bt:SetDisabledFontObject(BG.FontDis15)
        bt:SetHighlightFontObject(BG.FontWhite15)
        bt:SetText(L["拍卖记录"])
        bt:SetSize(bt:GetFontString():GetWidth(), 20)
        BG.SetTextHighlightTexture(bt)
        BG.ButtonAuctionLog = bt

        bt:SetScript("OnClick", function(self)
            if BG.auctionLogFrame:IsVisible() then
                BiaoGe.options.showAuctionLogFrame = 0
                BG.auctionLogFrame:Hide()
            else
                BiaoGe.options.showAuctionLogFrame = 1
                BG.auctionLogFrame:Show()
            end
            BG.PlaySound(1)
        end)
        bt:SetScript("OnEnter", function(self)
            local FB = BG.FB1
            local sum = 0
            local color = "00FF00"
            local tbl = BiaoGe[FB].auctionLog
            if tbl then
                for i, v in ipairs(tbl) do
                    if v.type == 1 then
                        sum = sum + (tonumber(v.jine) or 0)
                    end
                end
            end

            GameTooltip:SetOwner(self, "ANCHOR_NONE")
            GameTooltip:SetPoint("TOPLEFT", self, "BOTTOMLEFT")
            GameTooltip:ClearLines()
            GameTooltip:AddLine(self:GetText(), 1, 1, 1, true)
            GameTooltip:AddLine(L["自动拍卖装备（拍卖WA）的记录。"], 1, 0.82, 0, true)
            GameTooltip:AddLine(format(L["自动拍卖合计收入：|cff%s%s|r"], color, BG.FormatNumber(sum, 2)), 1, 0.82, 0, true)
            GameTooltip:Show()
        end)
        bt:SetScript("OnLeave", GameTooltip_Hide)
    end

    local frame, child, scroll
    local CancelAllChoose
    local drag = {}

    -- 主界面
    local f = CreateFrame("Frame", nil, BG.MainFrame, "BackdropTemplate")
    local dropDown = LibBG:Create_UIDropDownMenu(nil, f)
    do
        do
            f:SetBackdrop({
                bgFile = "Interface/ChatFrame/ChatFrameBackground",
                edgeFile = "Interface/ChatFrame/ChatFrameBackground",
                edgeSize = 1,
            })
            f:SetBackdropColor(0, 0, 0, 0.8)
            f:SetBackdropBorderColor(GetClassRGB(nil, "player", BG.borderAlpha))
            f:SetSize(220, BG.FBHeight[BG.FB1])
            f:SetPoint("TOPRIGHT", BG.MainFrame, "TOPLEFT", 1, 0)
            f:EnableMouse(true)
            f:SetShown(BiaoGe.options.showAuctionLogFrame == 1)
            BG.auctionLogFrame = f
            f:SetScript("OnShow", function(self)
                BG.UpdateAuctionLogFrame()
            end)
            f:SetScript("OnMouseUp", function(self)
                BG.MainFrame:GetScript("OnMouseUp")(BG.MainFrame)
            end)
            f:SetScript("OnMouseDown", function(self)
                BG.MainFrame:GetScript("OnMouseDown")(BG.MainFrame)
            end)


            BG.CreateCloseButton(f, BG.IsRetail and 0 or -5, nil, "TOPLEFT")
            f.CloseButton:HookScript("OnClick", function(self)
                BiaoGe.options.showAuctionLogFrame = 0
            end)

            local t = f:CreateFontString()
            t:SetFont(BIAOGE_TEXT_FONT, 15, "OUTLINE")
            t:SetPoint("TOP", f, "TOP", 0, -5)
            BG.auctionLogFrame.title = t

            -- 提示
            local bt = CreateFrame("Button", nil, f)
            bt:SetSize(28, 28)
            bt:SetPoint("LEFT", BG.auctionLogFrame.title, "RIGHT", 0, -1)
            local tex = bt:CreateTexture()
            tex:SetAllPoints()
            tex:SetTexture(616343)
            bt:SetHighlightTexture(616343)
            bt:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_NONE")
                GameTooltip:SetPoint("TOPLEFT", self, "BOTTOMLEFT")
                GameTooltip:ClearLines()
                local r, g, b = t:GetTextColor()
                GameTooltip:AddLine(t:GetText(), r, g, b)
                GameTooltip:AddLine(L["自动拍卖装备（拍卖WA）的记录。该记录会跟随清空表格一起被清空。"], 1, 0.82, 0, true)
                GameTooltip:AddLine(" ", 1, 0.82, 0, true)
                GameTooltip:AddLine(L["操作提示："], 1, 1, 1, true)
                GameTooltip:AddLine(AddTexture("RIGHT") .. L["点击一个装备可以打开菜单"], 1, 0.82, 0, true)
                GameTooltip:AddLine(L["未拍和流拍页可以按住CTRL、SHIFT，或者框选来多选装备，便于团长批量发起拍卖"], 1, 0.82, 0, true)
                GameTooltip:Show()
            end)
            bt:SetScript("OnLeave", GameTooltip_Hide)
        end

        -- 筛选显示
        do
            local buttons = {}
            local w = 48
            local numOptions = {
                { name = L["全部"], id = 1, row = 1, width = 0, },
                { name = L["未拍"], id = 4, row = 1, width = w, },
                { name = L["拍重"], id = 7, row = 1, width = w * 2, },
                { name = L["我买的"], id = 6, row = 1, width = w * 3, },
                { name = L["流拍"], id = 3, row = 2, width = 0, },
                { name = L["成功"], id = 2, row = 2, width = w, },
                { name = L["成功(未交易)"], id = 5, row = 2, width = w * 2, },
            }
            local buttonGroup = CreateFrame("Frame", nil, f)
            buttonGroup:SetPoint("TOPLEFT", 7, -38)
            buttonGroup:SetSize(1, 1)
            for i = 1, #numOptions do
                local v = numOptions[i]
                local bt = CreateFrame("CheckButton", nil, buttonGroup, "UIRadioButtonTemplate")
                bt:SetPoint("LEFT", v.width, -(v.row - 1) * 20)
                bt:SetSize(15, 15)
                tinsert(buttons, bt)
                bt.Text = bt:CreateFontString()
                bt.Text:SetFont(BIAOGE_TEXT_FONT, 15, "OUTLINE")
                bt.Text:SetPoint("LEFT", bt, "RIGHT", 0, 0)
                bt.Text:SetText(v.name)
                bt.Text:SetTextColor(1, .82, 0)
                bt:SetHitRectInsets(0, -bt.Text:GetWidth(), -5, -5)

                if v.id == BiaoGe.options.auctionLogChoose then
                    bt:SetChecked(true)
                    bt.Text:SetTextColor(0, 1, 0)
                end

                bt:SetScript("OnClick", function(self)
                    BG.PlaySound(1)
                    for _, radioButton in ipairs(buttons) do
                        if radioButton ~= self then
                            radioButton:SetChecked(false)
                            radioButton.Text:SetTextColor(1, .82, 0)
                        end
                    end
                    self:SetChecked(true)
                    self.Text:SetTextColor(0, 1, 0)
                    BiaoGe.options.auctionLogChoose = v.id
                    BG.auctionLogFrame.changeFrame:Hide()
                    BG.UpdateAuctionLogFrame()
                    LibBG:CloseDropDownMenus()
                    if BG.StartAucitonFrame and BG.StartAucitonFrame:IsVisible() then
                        BG.StartAucitonFrame:Hide()
                    end
                end)
            end

            local l = buttons[1]:CreateLine()
            l:SetColorTexture(RGB("808080", 1))
            l:SetStartPoint("BOTTOMLEFT", 0, -2)
            l:SetEndPoint("BOTTOMLEFT", 205, -2)
            l:SetThickness(1)

            local l = buttons[5]:CreateLine()
            l:SetColorTexture(RGB("808080", 1))
            l:SetStartPoint("BOTTOMLEFT", 0, -2)
            l:SetEndPoint("BOTTOMLEFT", 195, -2)
            l:SetThickness(1)
        end

        -- 滚动框
        do
            frame = CreateFrame("Frame", nil, BG.auctionLogFrame, "BackdropTemplate")
            frame:SetBackdrop({
                edgeFile = "Interface/ChatFrame/ChatFrameBackground",
                edgeSize = 1,
            })
            frame:SetBackdropBorderColor(.5, .5, .5, .5)
            frame:SetBackdropColor(0, 0, 0, 0.8)
            frame:SetPoint("TOPLEFT", 5, -73)
            frame:SetPoint("BOTTOMRIGHT", -5, 115)
            frame:EnableMouse(true)

            scroll = CreateFrame("ScrollFrame", nil, frame, "UIPanelScrollFrameTemplate")
            scroll:SetPoint("TOPLEFT", 5, -5)
            scroll:SetPoint("BOTTOMRIGHT", -26, 5)
            scroll.ScrollBar.scrollStep = BG.scrollStep
            frame.scroll = scroll
            BG.CreateSrollBarBackdrop(scroll.ScrollBar)
            BG.HookScrollBarShowOrHide(scroll)

            child = CreateFrame("Frame", nil, scroll)
            child:SetAllPoints()
            child:SetWidth(scroll:GetWidth())
            child:SetHeight(scroll:GetHeight())
            child:RegisterForDrag("LeftButton")
            scroll:SetScrollChild(child)

            local _f = CreateFrame("Frame", nil, frame)
            _f:SetSize(1, 1)
            _f:SetPoint("TOPRIGHT", 0, 1)
            frame.tooltip = _f

            local t = child:CreateFontString()
            t:SetFont(BIAOGE_TEXT_FONT, 15, "OUTLINE")
            t:SetPoint("TOP", 0, 0)
            t:SetTextColor(1, 0, 0)
            t:SetText(L["没有自动拍卖记录。"])
            t:SetWidth(scroll:GetWidth())
            t:Hide()
            BG.auctionLogFrame.notText = t
        end

        -- 开始拍卖
        do
            local bt = BG.CreateButton(frame)
            -- bt:SetPoint("TOPLEFT", frame, "BOTTOM", -10, 30)
            -- bt:SetPoint("BOTTOMRIGHT", frame, -22, 2)
            bt:SetPoint("TOPLEFT", frame, "TOP", -10, -2)
            bt:SetPoint("BOTTOMRIGHT", frame, 'TOPRIGHT', -24, -26)
            bt:SetFrameLevel(110)
            bt:SetText(L["开始拍卖"])
            bt:RegisterForClicks("AnyUp")
            bt:Hide()
            BG.auctionLogFrame.ButtonStartAuction = bt
            bt:SetScript("OnClick", function(self, button)
                BG.PlaySound(1)
                if BiaoGe.options.auctionLogChoose == 3 then
                    local db = BiaoGe[BG.FB1].auctionLog
                    local isGen2 = BiaoGe.Auction.gen == 2
                    local mod = BiaoGe.Auction.mod
                    local resetThreshold = max(tonumber(BiaoGe.Auction.resetThreshold) or 0, 10)
                    local indexs = {}
                    for _, v in ipairs(BG.auctionLogFrame.choosed) do
                        if v.money and v.index then
                            tinsert(indexs, v.index)
                        end
                    end
                    sort(indexs, function(a, b)
                        return a > b
                    end)
                    for _, index in ipairs(indexs) do
                        if db[index].type == 2 then
                            tremove(db, index)
                        end
                    end
                    local delay = 0
                    for _, v in ipairs(BG.auctionLogFrame.choosed) do
                        if v.money then
                            BG.After(delay, function()
                                BG.SendStartAuctionMsg(isGen2, v.id, v.money, 20, mod, v.link, resetThreshold)
                            end)
                            delay = delay + 1
                        end
                    end
                elseif BiaoGe.options.auctionLogChoose == 4 then
                    BG.StartAuction(BG.auctionLogFrame.choosed, bt, nil, true)
                    if BG.StartAucitonFrame and BG.StartAucitonFrame:IsVisible() then
                        BG.StartAucitonFrame:ClearAllPoints()
                        -- BG.StartAucitonFrame:SetPoint("BOTTOM", frame, 0, 0)
                        BG.StartAucitonFrame:SetPoint("TOP", frame, 0, 0)
                    end
                end
                CancelAllChoose()
            end)

            local bt = BG.CreateButton(BG.auctionLogFrame.ButtonStartAuction)
            -- bt:SetPoint("TOPLEFT", frame, "BOTTOMLEFT", 2, 30)
            -- bt:SetPoint("BOTTOMRIGHT", frame, "BOTTOM", -8, 2)
            bt:SetPoint("TOPLEFT", frame, "TOPLEFT", 2, -2)
            bt:SetPoint("BOTTOMRIGHT", frame, "TOP", -10, -26)
            bt:SetFrameLevel(110)
            bt:SetText(L["取消选择"])
            BG.auctionLogFrame.ButtonCancelChoose = bt
            bt:SetScript("OnClick", function(self)
                BG.PlaySound(1)
                CancelAllChoose()
            end)
        end

        -- 合计收入
        do
            local t = f:CreateFontString()
            t:SetFont(BIAOGE_TEXT_FONT, 15, "OUTLINE")
            t:SetPoint("TOPLEFT", frame, "BOTTOMLEFT", 2, -5)
            t:SetTextColor(1, 1, 1)
            t:SetJustifyH("LEFT")
            t:SetWordWrap(false)
            BG.auctionLogFrame.sumText = t
        end

        -- 增加
        do
            local bt = BG.CreateButton(BG.auctionLogFrame)
            bt:SetSize(28, 20)
            bt:SetPoint("TOPRIGHT", frame, "BOTTOMRIGHT", 0, -3)
            bt:SetText("+")
            BG.auctionLogFrame.ButtonAdd = bt
            bt:SetScript("OnClick", function(self)
                BG.PlaySound(1)
                if BG.auctionLogFrame.changeFrame:IsVisible() and BG.auctionLogFrame.changeFrame.type == "new" then
                    BG.auctionLogFrame.changeFrame:Hide()
                else
                    BG.auctionLogFrame.changeFrame:Hide()
                    BG.auctionLogFrame.changeFrame.type = "new"
                    BG.auctionLogFrame.changeFrame.info = {}
                    BG.auctionLogFrame.changeFrame:Show()
                    BG.auctionLogFrame.changeFrame:ClearAllPoints()
                    BG.auctionLogFrame.changeFrame:SetPoint("BOTTOM", frame, "BOTTOM", 0, 0)
                end
            end)
        end

        -- 搜索
        do
            -- local edit = CreateFrame("EditBox", nil, f, BG.editSearchTemplate)
            local edit = CreateFrame("EditBox", nil, f, 'SearchBoxTemplate')
            edit:SetSize(f:GetWidth() - 20, 22)
            edit:SetPoint("TOPLEFT", BG.auctionLogFrame.sumText, "BOTTOMLEFT", 7, -5)
            edit.Instructions:SetText(L["搜索装备/买家/金额"])
            BG.auctionLogFrame.serachEdit = edit
            edit:SetScript("OnMouseDown", function(self, button)
                if button == "RightButton" then
                    self:SetEnabled(false)
                    self:SetText("")
                end
            end)
            edit:SetScript("OnMouseUp", function(self, button)
                self:SetEnabled(true)
            end)
            edit:SetScript("OnEditFocusGained", function(self)
                BG.lastfocus = self
            end)
        end
    end

    -- 生成账单
    do
        -- 生成表格账单
        do
            function GetErrorItem(tbl, logCountOver1)
                local FB = BG.FB1
                tbl = tbl or BiaoGe[FB].auctionLog
                local items = {}
                for index, v in ipairs(tbl) do
                    if v.type == 1 then
                        local itemID = GetItemID(v.zhuangbei)
                        if not items[itemID] then
                            items[itemID] = {}
                            items[itemID].info = {}
                            items[itemID].indexs = {}
                            items[itemID].link = v.zhuangbei
                            items[itemID].logCount = 0
                        end
                        tinsert(items[itemID].info, v)
                        tinsert(items[itemID].indexs, index)
                        items[itemID].logCount = items[itemID].logCount + 1
                    end
                end
                if next(items) then
                    if logCountOver1 then
                        local ids = {}
                        for itemID, v in pairs(items) do
                            tinsert(ids, itemID)
                        end
                        for _, itemID in ipairs(ids) do
                            if items[itemID].logCount <= 1 then
                                items[itemID] = nil
                            end
                        end
                    end
                    BG.PairFBItem(function(zhuangbei)
                        local itemID = GetItemID(zhuangbei:GetText())
                        if itemID and items[itemID] then
                            items[itemID].bgCount = items[itemID].bgCount or 0
                            items[itemID].bgCount = items[itemID].bgCount + 1
                        end
                    end)
                    local tbl = {}
                    for itemID, v in pairs(items) do
                        if not v.bgCount or v.bgCount < v.logCount then
                            v.itemID = itemID
                            v.bgCount = v.bgCount or 0
                            tinsert(tbl, v)
                        end
                    end
                    if next(tbl) then
                        return tbl
                    end
                end
            end

            local function HasQK()
                local has
                BG.PairFBItem(function(item, buyer, money, b, i)
                    if BiaoGe[BG.FB1]["boss" .. b]["qiankuan" .. i] then
                        has = true
                        return true
                    end
                end)
                return has
            end

            local bt = BG.CreateButton(BG.auctionLogFrame)
            bt:SetSize(110, 25)
            bt:SetPoint("BOTTOMLEFT", BG.auctionLogFrame, 5, 5)
            bt:SetText(L["生成表格账单"])
            BG.auctionLogFrame.ButtonCreateLedger = bt
            bt:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT", 0, 0)
                GameTooltip:ClearLines()
                GameTooltip:AddLine(self:GetText(), 1, 1, 1, true)
                GameTooltip:AddLine(L["根据自动拍卖记录，直接覆盖表格里每件装备所对应的买家和金额。"], 1, 0.82, 0, true)
                GameTooltip:AddLine(" ")
                GameTooltip:AddLine(L["该功能仅修改买家和金额，如果表格里的装备栏是空的，则什么都不会发生。"], 1, 0.82, 0, true)
                local errorTbl = GetErrorItem()
                if errorTbl then
                    GameTooltip:AddLine(" ", 1, 0, 0, true)
                    GameTooltip:AddLine(L["以下装备可能存在重复拍卖："], 1, 0, 0, true)
                    for _, v in ipairs(errorTbl) do
                        local icon = select(5, GetItemInfoInstant(v.itemID))
                        GameTooltip:AddLine(L["%s%s：拍卖成功%s件，表格实际只有%s件"]:format(AddTexture(icon), v.link, v.logCount, v.bgCount), 1, .82, 0)
                    end
                end
                GameTooltip:Show()
            end)
            bt:SetScript("OnLeave", GameTooltip_Hide)
            bt:SetScript("OnClick", function(self)
                if HasQK() then
                    local name = "BiaoGe_CreateBillByAuctionLog"
                    if not StaticPopupDialogs[name] then
                        StaticPopupDialogs[name] = {
                            text = L["你的当前表格含有|cffff0000欠款|r，生成表格账单可能会导致欠款金额与欠款人对应不上。\n\n确定继续生成表格账单吗？"],
                            button1 = L["是"],
                            button2 = L["否"],
                            OnCancel = function()
                            end,
                            timeout = 0,
                            whileDead = true,
                            hideOnEscape = true,
                            showAlert = true,
                        }
                    end
                    StaticPopupDialogs[name].OnAccept = function()
                        BG.PlaySound(2)
                        BG.CreateBillByAuctionLog()
                    end
                    StaticPopup_Show(name)
                else
                    BG.PlaySound(2)
                    BG.CreateBillByAuctionLog()
                end
            end)

            function BG.CreateBillByAuctionLog(FB)
                FB = FB or BG.FB2 or BG.FB1
                if not BiaoGe[FB].auctionLog then return end
                for b = 1, Maxb[FB] - 1 do
                    for i = 1, BG.GetMaxi(FB, b) do
                        local zhuangbei = BG.Frame[FB]["boss" .. b]["zhuangbei" .. i]
                        local maijia = BG.Frame[FB]["boss" .. b]["maijia" .. i]
                        local jine = BG.Frame[FB]["boss" .. b]["jine" .. i]
                        if zhuangbei then
                            maijia:SetText("")
                            maijia:SetTextColor(1, 1, 1)
                            BiaoGe[FB]["boss" .. b]["maijia" .. i] = nil
                            for k, v in pairs(BG.playerClass) do
                                BiaoGe[FB]["boss" .. b][k .. i] = nil
                            end
                            jine:SetText("")
                            BiaoGe[FB]["boss" .. b]["jine" .. i] = nil
                        end
                    end
                end
                BiaoGe[FB].tradeTbl = {}

                for index = #BiaoGe[FB].auctionLog, 1, -1 do
                    local v = BiaoGe[FB].auctionLog[index]
                    if v.type == 1 then
                        local itemID = GetItemID(v.zhuangbei)
                        for b = 1, Maxb[FB] - 1 do
                            local yes
                            for i = 1, BG.GetMaxi(FB, b) do
                                local zhuangbei = BG.Frame[FB]["boss" .. b]["zhuangbei" .. i]
                                local maijia = BG.Frame[FB]["boss" .. b]["maijia" .. i]
                                local jine = BG.Frame[FB]["boss" .. b]["jine" .. i]
                                if zhuangbei and GetItemID(zhuangbei:GetText()) == itemID and
                                    maijia:GetText() == "" and jine:GetText() == ""
                                then
                                    yes = true
                                    maijia:SetText(v.maijia or "")
                                    BiaoGe[FB]["boss" .. b]["maijia" .. i] = v.maijia
                                    if v.color then
                                        maijia:SetTextColor(unpack(v.color))
                                    else
                                        maijia:SetTextColor(1, 1, 1)
                                    end
                                    for k in pairs(BG.playerClass) do
                                        BiaoGe[FB]["boss" .. b][k .. i] = v[k]
                                    end

                                    jine:SetText(v.jine or "")
                                    BiaoGe[FB]["boss" .. b]["jine" .. i] = v.jine
                                    break
                                end
                            end
                            if yes then break end
                        end
                    end
                end

                -- 已移除 CP 货币结算挂载点（第三方付费模块 BGV 提供）
            end

            function BG.IsAutoCreateBill()
                return BiaoGe.options.autoCreateBill == 1 and not BG.IsML
            end
        end

        -- 生成对账单
        do
            local bt = BG.CreateButton(BG.auctionLogFrame)
            bt:SetSize(95, 25)
            bt:SetPoint("BOTTOMRIGHT", BG.auctionLogFrame, -5, 5)
            bt:SetText(L["生成对账单"])
            BG.auctionLogFrame.ButtonCreateDuiZhang = bt
            bt:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT", 0, 0)
                GameTooltip:ClearLines()
                GameTooltip:AddLine(self:GetText(), 1, 1, 1, true)
                GameTooltip:AddLine(L["根据自动拍卖记录，生成一个对账单。"], 1, 0.82, 0, true)
                GameTooltip:Show()
            end)
            bt:SetScript("OnLeave", GameTooltip_Hide)
            bt:SetScript("OnClick", function(self)
                BG.PlaySound(2)
                local FB = BG.FB1
                local duizhang = {}
                duizhang.addons = "biaoge"
                duizhang.FB = FB
                duizhang.t = GetServerTime()
                duizhang.time = date("%m-%d %H:%M:%S", GetServerTime())
                duizhang.msgTbl = {}
                duizhang.player = BG.STC_g1(L["自动拍卖记录"])
                duizhang.sumjine = 0
                duizhang.zhangdan = {}
                local num = 0
                for i, v in ipairs(BiaoGe[FB].auctionLog) do
                    if v.type == 1 then
                        num = num + 1
                        duizhang.zhangdan[num] = BG.Copy(v)
                        duizhang.zhangdan[num].type = nil
                        duizhang.zhangdan[num].time = nil
                        duizhang.zhangdan[num].bindType = nil
                        duizhang.zhangdan[num].itemlevel = nil
                        duizhang.zhangdan[num].quality = nil
                        duizhang.sumjine = duizhang.sumjine + (tonumber(v.jine) or 0)
                    end
                end
                tinsert(BiaoGe.duizhang, duizhang)
                BG.DuiZhangList()
            end)
        end

        -- 自动生成账单
        do
            local bt = CreateFrame("CheckButton", nil, f, "ChatConfigCheckButtonTemplate")
            bt:SetSize(30, 30)
            bt:SetPoint("BOTTOMLEFT", BG.auctionLogFrame.ButtonCreateLedger, "TOPLEFT", 0, 0)
            bt.Text:SetFont(BIAOGE_TEXT_FONT, 15, "OUTLINE")
            bt.Text:SetText(AddTexture("QUEST") .. L["自动生成表格账单"])
            bt.Text:SetWidth(min(bt.Text:GetWidth() + 20, BG.auctionLogFrame:GetWidth() - 40))
            bt.Text:SetWordWrap(false)
            bt:SetHitRectInsets(0, -bt.Text:GetWidth(), 0, 0)
            bt:SetChecked(BiaoGe.options.autoCreateBill == 1)
            bt:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT", 0, 0)
                GameTooltip:ClearLines()
                GameTooltip:AddLine(self.Text:GetText(), 1, 1, 1, true)
                GameTooltip:AddLine(L["当一个装备拍卖成功时，会根据拍卖记录，自动填写表格里该装备所对应的买家和金额。"], 1, 0.82, 0, true)
                GameTooltip:AddLine(" ", 1, 0.82, 0, true)
                GameTooltip:AddLine(L["启用该功能时，交易记账会被自动禁用，以免记账冲突。"], 1, 0.82, 0, true)
                GameTooltip:AddLine(" ", 1, 0.82, 0, true)
                GameTooltip:AddLine(L["注意：如果你是团长或物品分配者，该功能不会生效。团长或物品分配者仍会使用更为可靠的交易记账。"], 1, 0, 0, true)
                GameTooltip:Show()
            end)
            bt:SetScript("OnLeave", GameTooltip_Hide)
            bt:SetScript("OnClick", function(self)
                BG.PlaySound(1)
                BiaoGe.options.autoCreateBill = self:GetChecked() and 1 or 0
                BG.UpdateAutoCreateBillButton()
            end)

            function BG.UpdateAutoCreateBillButton()
                bt:SetChecked(BiaoGe.options.autoCreateBill == 1)
                BG.options["buttonautoCreateBill"]:SetChecked(BiaoGe.options.autoCreateBill == 1)
            end
        end
    end

    -- 增加记录
    do
        local f = CreateFrame("Frame", nil, BG.auctionLogFrame, "BackdropTemplate")
        do
            f:SetBackdrop({
                bgFile = "Interface/ChatFrame/ChatFrameBackground",
                edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
                edgeSize = 10,
                insets = { left = 3, right = 3, top = 3, bottom = 3 }
            })
            f:SetBackdropColor(0, 0, 0, 0.8)
            f:SetSize(220, 140)
            f:SetFrameLevel(117)
            f:EnableMouse(true)
            f:Hide()
            BG.auctionLogFrame.changeFrame = f
            f:SetScript("OnMouseDown", function(self)
                if BG.FrameZhuangbeiList then
                    BG.FrameZhuangbeiList:Hide()
                end
                BG.ClearFocus()
            end)
            f:SetScript("OnShow", function(self)
                if BG.auctionLogFrame.changeFrame.type == "change" then
                    f.item:Show()
                    f.zhuangbei:Hide()
                    f.title:SetText(BG.auctionLogFrame.changeFrame.typeText)
                    f.ButtonSure:Enable()
                elseif BG.auctionLogFrame.changeFrame.type == "new" then
                    f.item:Hide()
                    f.zhuangbei:Show()
                    f.zhuangbei:SetFocus()
                    f.title:SetText(L["增加记录"])
                    f.ButtonSure:Disable()
                elseif BG.auctionLogFrame.changeFrame.type == "set" then
                    f.item:Show()
                    f.zhuangbei:Hide()
                    f.title:SetText(L["设为已拍"])
                    f.ButtonSure:Disable()
                end
                f.zhuangbei:SetText("")
                f.maijia:SetText("")
                f.jine:SetText("")
            end)

            local t = f:CreateFontString()
            t:SetFont(BIAOGE_TEXT_FONT, 15, "OUTLINE")
            t:SetPoint("TOP", 0, -10)
            f.title = t
        end
        -- 装备
        do
            local title = f:CreateFontString()
            title:SetFont(BIAOGE_TEXT_FONT, 15, "OUTLINE")
            title:SetPoint("TOPLEFT", 5, -35)
            title:SetText(L["装备："])
            title:SetTextColor(1, 0.82, 0)
            title:SetWidth(60)
            title:SetJustifyH("RIGHT")
            title:SetWordWrap(false)

            -- 修改装备
            do
                local _f = CreateFrame("Frame", nil, BG.auctionLogFrame.changeFrame, "BackdropTemplate")
                _f:SetPoint("LEFT", title, "RIGHT", 10, 0)
                _f:SetSize(120, 15)
                _f:SetHyperlinksEnabled(true)
                local t = _f:CreateFontString()
                t:SetFont(BIAOGE_TEXT_FONT, 15, "OUTLINE")
                t:SetAllPoints()
                t:SetJustifyH("LEFT")
                t:SetWordWrap(false)
                f.item = t
                t.title = title
                _f:SetScript("OnHyperlinkEnter", function(self, link, text, button)
                    local itemID = GetItemInfoInstant(link)
                    if itemID then
                        GameTooltip:SetOwner(self, "ANCHOR_RIGHT", -self:GetWidth() + t:GetWrappedWidth(), 0)
                        GameTooltip:ClearLines()
                        GameTooltip:SetHyperlink(BG.SetSpecIDToLink(link))
                    end
                end)
                _f:SetScript("OnHyperlinkLeave", GameTooltip_Hide)
            end

            -- 手动添加装备
            do
                local edit = CreateFrame("EditBox", nil, f, BG.editTemplate)
                edit:SetSize(110, 20)
                edit:SetPoint("LEFT", title, "RIGHT", 10, 0)
                edit:SetAutoFocus(false)
                f.zhuangbei = edit
                edit:SetScript("OnEditFocusGained", function(self)
                    self:HighlightText()
                    BG.lastfocus = self
                end)
                edit:SetScript("OnTextChanged", function(self)
                    if GetItemID(self:GetText()) and GetItemInfoInstant(self:GetText()) then
                        f.ButtonSure:Enable()
                    else
                        f.ButtonSure:Disable()
                    end
                end)
                edit:SetScript("OnMouseDown", function(self, button)
                    if BG.auctionLogFrame.changeFrame.type == "set" then return end
                    if button == "RightButton" then
                        self:SetEnabled(false)
                        self:SetText("")
                        return
                    end
                end)
                edit:SetScript("OnMouseUp", function(self, button)
                    if BG.auctionLogFrame.changeFrame.type == "set" then return end
                    local infoType, itemID, itemLink = GetCursorInfo()
                    if infoType == "item" then
                        self:SetText(itemLink)
                        self:ClearFocus()
                        ClearCursor()
                    end
                    self:SetEnabled(true)
                end)
                edit:SetScript("OnEnter", function(self, button)
                    if not tonumber(self:GetText()) then
                        local link = self:GetText()
                        local itemID = GetItemInfoInstant(link)
                        if itemID then
                            GameTooltip:SetOwner(self, "ANCHOR_RIGHT", 0, 0)
                            GameTooltip:ClearLines()
                            GameTooltip:SetHyperlink(BG.SetSpecIDToLink(link))
                        end
                    end
                end)
                edit:SetScript("OnLeave", GameTooltip_Hide)

                -- 提示
                local bt = CreateFrame("Button", nil, edit)
                bt:SetSize(28, 28)
                bt:SetPoint("LEFT", edit, "RIGHT", 0, -1)
                f.zhuangbei.tip = bt
                local tex = bt:CreateTexture()
                tex:SetAllPoints()
                tex:SetTexture(616343)
                bt:SetHighlightTexture(616343)
                bt:SetScript("OnEnter", function(self)
                    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                    GameTooltip:ClearLines()
                    GameTooltip:AddLine(L["添加装备"], 1, 1, 1, true)
                    GameTooltip:AddLine(L["按住Shift+点击表格/背包/聊天框装备；直接把装备拖到格子里"], 1, 0.82, 0, true)
                    GameTooltip:Show()
                end)
                bt:SetScript("OnLeave", GameTooltip_Hide)
            end
        end
        -- 买家
        do
            local t = f:CreateFontString()
            t:SetFont(BIAOGE_TEXT_FONT, 15, "OUTLINE")
            t:SetPoint("TOPLEFT", f.item.title, "BOTTOMLEFT", 0, -7)
            t:SetText(L["买家："])
            t:SetTextColor(1, 0.82, 0)
            t:SetWidth(60)
            t:SetJustifyH("RIGHT")
            t:SetWordWrap(false)
            local edit = CreateFrame("EditBox", nil, f, BG.editTemplate)
            edit:SetSize(110, 20)
            edit:SetPoint("LEFT", t, "RIGHT", 10, 0)
            edit:SetAutoFocus(false)
            BG.SetEditStickyFocus(edit)
            edit.title = t
            f.maijia = edit
            edit:SetScript("OnTextChanged", function(self)
                if self:GetText() == "" then
                    self:SetTextColor(1, 1, 1)
                    BG.auctionLogFrame.changeFrame.info.maijia = nil
                    BG.auctionLogFrame.changeFrame.info.color = nil
                    if BG.FrameMaijiaList then
                        BG.FrameMaijiaList:Hide()
                    end
                else
                    BG.auctionLogFrame.changeFrame.info.maijia = self:GetText()
                    BG.auctionLogFrame.changeFrame.info.color = { self:GetTextColor() }
                end
                if BG.auctionLogFrame.changeFrame.type == "set" then
                    if self:GetText() ~= "" or f.maijia:GetText() ~= "" then
                        f.ButtonSure:Enable()
                    else
                        f.ButtonSure:Disable()
                    end
                end
            end)
            edit:SetScript("OnEditFocusGained", function(self)
                self:HighlightText()
                BG.lastfocus = self
                BG.SetListmaijia(self, true, nil, true)
            end)
            edit:SetScript("OnEditFocusLost", function(self)
                self:ClearHighlightText()
                if BG.FrameMaijiaList then
                    BG.FrameMaijiaList:Hide()
                end
            end)
            edit:SetScript("OnEnterPressed", function(self)
                self:ClearFocus()
                if BG.FrameMaijiaList then
                    BG.FrameMaijiaList:Hide()
                end
            end)
            edit:SetScript("OnMouseDown", function(self, enter)
                if enter == "RightButton" then
                    self:SetEnabled(false)
                    self:SetText("")
                    if BG.lastfocus then
                        BG.lastfocus:ClearFocus()
                    end
                end
            end)
            edit:SetScript("OnMouseUp", function(self, enter)
                self:SetEnabled(true)
            end)
        end
        -- 金额
        do
            local t = f:CreateFontString()
            t:SetFont(BIAOGE_TEXT_FONT, 15, "OUTLINE")
            t:SetPoint("TOPLEFT", f.maijia.title, "BOTTOMLEFT", 0, -7)
            t:SetText(L["金额："])
            t:SetTextColor(1, 0.82, 0)
            t:SetWidth(60)
            t:SetJustifyH("RIGHT")
            t:SetWordWrap(false)
            local edit = CreateFrame("EditBox", nil, f, BG.editTemplate)
            edit:SetSize(110, 20)
            edit:SetPoint("LEFT", t, "RIGHT", 10, 0)
            edit:SetAutoFocus(false)
            edit:SetNumeric(true)
            BG.SetEditStickyFocus(edit)
            f.jine = edit
            edit:SetScript("OnTextChanged", function(self)
                BG.UpdateTwo0(self)
                if self:GetText() == "" then
                    BG.auctionLogFrame.changeFrame.info.jine = nil
                else
                    BG.auctionLogFrame.changeFrame.info.jine = self:GetText()
                end
                if BG.auctionLogFrame.changeFrame.type == "set" then
                    if self:GetText() ~= "" or f.maijia:GetText() ~= "" then
                        f.ButtonSure:Enable()
                    else
                        f.ButtonSure:Disable()
                    end
                end
            end)
            edit:SetScript("OnEditFocusGained", function(self)
                self:HighlightText()
                BG.lastfocus = self
                local f = BG.CreateNumFrame(BG.auctionLogFrame.changeFrame)
                if f then
                    f:ClearAllPoints()
                    f:SetPoint("TOPLEFT", BG.auctionLogFrame.changeFrame, "TOPRIGHT", 0, 0)
                end
            end)
            edit:HookScript("OnEditFocusLost", function(self)
                if BG.FrameNumFrame then
                    BG.FrameNumFrame:Hide()
                end
            end)
            edit:SetScript("OnEnterPressed", function(self)
                f.ButtonSure:GetScript("OnClick")()
            end)
            edit:SetScript("OnMouseDown", function(self, enter)
                if enter == "RightButton" then
                    self:SetEnabled(false)
                    self:SetText("")
                    if BG.lastfocus then
                        BG.lastfocus:ClearFocus()
                    end
                end
            end)
            edit:SetScript("OnMouseUp", function(self, enter)
                self:SetEnabled(true)
            end)
        end
        -- 按钮
        do
            local bt = BG.CreateButton(f)
            bt:SetSize(95, 22)
            bt:SetPoint("BOTTOMLEFT", 10, 10)
            bt:SetText(L["确定"])
            f.ButtonSure = bt
            bt:SetScript("OnClick", function(self)
                BG.PlaySound(1)
                local FB = BG.FB1
                if BG.auctionLogFrame.changeFrame.type == "change" then
                    local i = BG.auctionLogFrame.changeFrame.info.num
                    if not (BG.auctionLogFrame.changeFrame.info.maijia or BG.auctionLogFrame.changeFrame.info.jine) then
                        BiaoGe[FB].auctionLog[i].type = 2
                        BiaoGe[FB].auctionLog[i].maijia = nil
                        BiaoGe[FB].auctionLog[i].jine = nil
                    else
                        BiaoGe[FB].auctionLog[i].type = 1
                        BiaoGe[FB].auctionLog[i].maijia = BG.auctionLogFrame.changeFrame.info.maijia or ""
                        BiaoGe[FB].auctionLog[i].jine = BG.auctionLogFrame.changeFrame.info.jine or ""
                    end
                    for k in pairs(BG.playerClass) do
                        BiaoGe[FB].auctionLog[i][k] = BG.auctionLogFrame.changeFrame.info[k]
                    end
                    f:Hide()
                    BG.UpdateAuctionLogFrame(true)
                elseif BG.auctionLogFrame.changeFrame.type == "new" or BG.auctionLogFrame.changeFrame.type == "set" then
                    local zhuangbei
                    if BG.auctionLogFrame.changeFrame.type == "new" then
                        zhuangbei = f.zhuangbei:GetText()
                    elseif BG.auctionLogFrame.changeFrame.type == "set" then
                        zhuangbei = f.item:GetText():gsub("|T.+|t", ""):gsub(":|h", ":|h["):gsub("|h|r", "]|h|r")
                    end

                    local name, link, quality, level, _, _, _, _, EquipLoc, Texture,
                    _, typeID, subclassID, bindType = GetItemInfo(zhuangbei)
                    local a = {
                        time = GetServerTime(),
                        zhuangbei = zhuangbei,
                        itemlevel = level,
                        quality = quality,
                        bindType = bindType,
                    }

                    if not (BG.auctionLogFrame.changeFrame.info.maijia or BG.auctionLogFrame.changeFrame.info.jine) then
                        a.type = 2
                        a.maijia = nil
                        a.jine = nil
                    else
                        a.type = 1
                        a.maijia = BG.auctionLogFrame.changeFrame.info.maijia or ""
                        a.jine = BG.auctionLogFrame.changeFrame.info.jine or ""
                    end
                    for k in pairs(BG.playerClass) do
                        a[k] = BG.auctionLogFrame.changeFrame.info[k]
                    end
                    BiaoGe[FB].auctionLog = BiaoGe[FB].auctionLog or {}
                    tinsert(BiaoGe[FB].auctionLog, a)
                    f:Hide()
                    if BG.auctionLogFrame.changeFrame.type == "new" then
                        BG.UpdateAuctionLogFrame(nil, true)
                    elseif BG.auctionLogFrame.changeFrame.type == "set" then
                        BG.UpdateAuctionLogFrame(true, true)
                    end
                end
            end)

            local bt = BG.CreateButton(f)
            bt:SetSize(95, 22)
            bt:SetPoint("BOTTOMRIGHT", -10, 10)
            bt:SetText(CANCEL)
            bt:SetScript("OnClick", function(self)
                f:Hide()
            end)
        end
    end

    function BG.SetAuctionLogItemState(v, state, notClearMoney)
        -- 流拍
        if state == 2 then
            v.type = 2
            v.maijia = nil
            if not notClearMoney then
                v.jine = nil
            end
            v.trade = nil
            for k in pairs(BG.playerClass) do
                v[k] = nil
            end
        end
        BG.UpdateAuctionLogFrame(true, true)
    end

    BG.auctionLogFrame.auctioning = {}
    BG.auctionLogFrame.buttons = {}
    BG.auctionLogFrame.choosed = {}
    local lastChoose, needDeleteItem
    local reAuctionSendCD = 0

    local function DeleteLiuPaiAuctionLog() -- 在流拍列表重拍一个装备时，该装备的流拍记录会被删除
        local FB = BG.FB1
        if needDeleteItem and BiaoGe[FB].auctionLog then
            for i, v in ipairs(BiaoGe[FB].auctionLog) do
                if v == needDeleteItem.v then
                    tremove(BiaoGe[FB].auctionLog, i)
                    BG.UpdateAuctionLogFrame(true, true)
                    return
                end
            end
        end
    end
    local function AddNeedDeleteItem(index, v)
        needDeleteItem = { i = index, v = v }
    end

    local function UpdateButtonStartAuction()
        local bt = BG.auctionLogFrame.ButtonStartAuction
        if BiaoGe.options.auctionLogChoose == 3 then
            bt:SetText(L["一键重拍"])
        elseif BiaoGe.options.auctionLogChoose == 4 then
            bt:SetText(L["开始拍卖"])
        else
            bt:Hide()
        end
        if #BG.auctionLogFrame.choosed > 0 then
            bt:Show()
            if BG.IsML then
                bt:Enable()
            else
                bt:Disable()
            end
        else
            bt:Hide()
        end
    end
    -- 右键菜单
    local CreateMenu, AddLogLine
    do
        function AddLogLine(v)
            local t = v.time and L['剩余%s秒时出价']:format(v.time) or ''
            return format(L['%s、%s（%s）|cffff0000%s|r'], v.i, v.money, v.player, t)
        end

        function CreateMenu(f, index, v, noAuctioned, link, icon)
            local FB = BG.FB1
            local menu
            local function GetLogTooltipText()
                local text = ""
                local isMore = true
                local maxNum = 80
                if #v.log > maxNum then
                    for i = 1 + (#v.log - maxNum), #v.log do
                        local _v = v.log[i]
                        if _v.i == 1 then
                            isMore = false
                        end
                        text = text .. AddLogLine(_v) .. NN
                    end
                else
                    for i, _v in ipairs(v.log) do
                        if _v.i == 1 then
                            isMore = false
                        end
                        text = text .. AddLogLine(_v) .. NN
                    end
                end

                if isMore then
                    text = BG.STC_dis("......\n") .. text
                end
                return text
            end
            if noAuctioned then
                menu = {
                    {
                        isTitle = true,
                        text = link:gsub("%[", ""):gsub("%]", ""),
                        notCheckable = true,
                    },
                    {
                        isTitle = true,
                        text = "   ",
                        notCheckable = true,
                    },
                    {
                        text = L["设为已拍"],
                        notCheckable = true,
                        func = function()
                            BG.auctionLogFrame.changeFrame:Hide()
                            BG.auctionLogFrame.changeFrame.type = "set"
                            BG.auctionLogFrame.changeFrame.info = {}
                            BG.auctionLogFrame.changeFrame:Show()
                            BG.auctionLogFrame.changeFrame:ClearAllPoints()
                            BG.auctionLogFrame.changeFrame:SetPoint("TOP", f, "BOTTOM", 10, 0)
                            BG.auctionLogFrame.changeFrame.item:SetText(AddTexture(icon) .. v.zhuangbei:gsub("%[", ""):gsub("%]", ""))
                        end
                    },
                    {
                        text = L["设为流拍"],
                        notCheckable = true,
                        func = function()
                            BiaoGe[FB].auctionLog = BiaoGe[FB].auctionLog or {}
                            tinsert(BiaoGe[FB].auctionLog, {
                                type = 2,
                                time = GetServerTime(),
                                zhuangbei = v.zhuangbei,
                                itemlevel = v.level,
                                quality = v.quality,
                                bindType = v.bindType,
                            })
                            BG.UpdateAuctionLogFrame(true, true)
                        end
                    },
                    {
                        isTitle = true,
                        text = "   ",
                        notCheckable = true,
                    },
                    {
                        text = CANCEL,
                        notCheckable = true,
                        func = function(self)
                            LibBG:CloseDropDownMenus()
                        end,
                    }
                }
                if not BG.IsML and IsInRaid(1) then
                    tinsert(menu, 2, {
                        text = format("|cff%s%s|r", BG.TargetVerOver(BG.GetMLName(), 20070) and 'ffffff' or '808080', L['提醒团长拍卖']),
                        notCheckable = true,
                        func = function()
                            if GetTime() - reAuctionSendCD > 3 then
                                C_ChatInfo.SendAddonMessage("BiaoGe2", format("RemindAuction^%s^%s", GetItemID(link), link), "RAID")
                                BG.SendSystemMessage(L["已提醒团长拍卖："] .. link)
                                reAuctionSendCD = GetTime()
                            else
                                BG.SendSystemMessage(L["申请太频繁了，等待3秒后再尝试。"])
                            end
                        end,
                        tooltipTitle = L['提醒团长拍卖'],
                        tooltipText = L['团长的BGLite版本高于%s时才能收到你的请求。']:format('v2.0.7'),
                        tooltipOnButton = true,
                    })
                else
                    tinsert(menu, 2, {
                        text = L["开始拍卖"],
                        notCheckable = true,
                        func = function()
                            BG.StartAuction(link, f, true, true)
                        end
                    })
                end
            else
                menu = {
                    {
                        isTitle = true,
                        text = link:gsub("%[", ""):gsub("%]", ""),
                        notCheckable = true,
                    },
                    {
                        text = L["重新拍卖"],
                        disabled = not BG.IsML,
                        notCheckable = true,
                        func = function()
                            AddNeedDeleteItem(index, v)
                            BG.StartAuction(link, f, true, true, nil, nil, DeleteLiuPaiAuctionLog)
                        end
                    },
                    {
                        -- 修改记录
                        notCheckable = true,
                        func = function(self, arg1)
                            BG.auctionLogFrame.changeFrame:Hide()
                            BG.auctionLogFrame.changeFrame.type = "change"
                            BG.auctionLogFrame.changeFrame.typeText = arg1
                            BG.auctionLogFrame.changeFrame.info = {}
                            BG.auctionLogFrame.changeFrame.info.num = index
                            for k in pairs(BG.playerClass) do
                                BG.auctionLogFrame.changeFrame.info[k] = v[k]
                            end
                            BG.auctionLogFrame.changeFrame:Show()
                            BG.auctionLogFrame.changeFrame:ClearAllPoints()
                            BG.auctionLogFrame.changeFrame:SetPoint("TOP", f, "BOTTOM", 10, 0)
                            BG.auctionLogFrame.changeFrame.item:SetText(AddTexture(icon) .. link:gsub("%[", ""):gsub("%]", ""))
                            BG.auctionLogFrame.changeFrame.item.itemID = GetItemID(link)
                            BG.auctionLogFrame.changeFrame.maijia:ClearFocus()
                            BG.auctionLogFrame.changeFrame.maijia:SetText(v.maijia or "")
                            BG.auctionLogFrame.changeFrame.maijia:SetTextColor(unpack(v.color or { 1, 1, 1 }))
                            BG.auctionLogFrame.changeFrame.jine:ClearFocus()
                            BG.auctionLogFrame.changeFrame.jine:SetText(v.jine or "")
                        end
                    },
                    {
                        text = L["删除记录"],
                        notCheckable = true,
                        func = function()
                            BG.auctionLogFrame.changeFrame:Hide()
                            tremove(BiaoGe[FB].auctionLog, index)
                            BG.UpdateAuctionLogFrame(true, true)
                        end
                    },
                    {
                        isTitle = true,
                        text = "   ",
                        notCheckable = true,
                    },
                    {
                        text = CANCEL,
                        notCheckable = true,
                        func = function(self)
                            LibBG:CloseDropDownMenus()
                        end,
                    }
                }

                if v.type == 1 then
                    -- 成功
                    menu[3].text = L["修改记录"]
                    menu[3].arg1 = menu[3].text

                    local num = 2
                    if v.log then
                        tinsert(menu, num, {
                            text = L["出价记录"],
                            notCheckable = true,
                            tooltipTitle = L["出价记录"],
                            tooltipText = GetLogTooltipText(),
                            tooltipOnButton = true,
                        })
                        num = num + 1
                    end
                    num = num + 1
                    tinsert(menu, num, {
                        text = L["设为流拍"],
                        notCheckable = true,
                        func = function()
                            BG.SetAuctionLogItemState(v, 2)
                        end
                    })
                    num = num + 1
                    if v.trade then
                        tinsert(menu, num, {
                            text = L["设为未交易"],
                            notCheckable = true,
                            func = function()
                                v.trade = nil
                                BG.UpdateAuctionLogFrame(true, true)
                            end
                        })
                    else
                        tinsert(menu, num, {
                            text = L["设为已交易"],
                            notCheckable = true,
                            tooltipTitle = L["设为已交易"],
                            tooltipText = L["交易时不再显示该装备的应收/应付金额，团长也不会自动摆放该装备。"],
                            tooltipOnButton = true,
                            func = function()
                                v.trade = true
                                BG.UpdateAuctionLogFrame(true, true)
                            end
                        })
                    end
                    tinsert(menu, num + 1, {
                        isTitle = true,
                        text = "   ",
                        notCheckable = true,
                    })
                    -- 「交易玩家」「跟随玩家」：属金团收款/分金流程闭环的一部分 ——
                    -- 拍卖成功后团长需要与买家一对一交易来收取金额；交易要求双方处于交互距离内，
                    -- 「跟随玩家」用于走到买家身边，「交易玩家」用于开交易窗口，两者配套。
                    -- 同一菜单里的「设为已交易 / 设为未交易」也是收款状态管理，可佐证本菜单的用途。
                    -- InitiateTrade 只是「打开交易窗口」，双方仍需各自放入物品/金币并手动确认；
                    -- 它不移动任何金钱，与 AcceptTrade（代玩家完成交易）性质不同。
                    -- 两项保留均经策划确认；docs/07 §4.3 R2 需相应回填豁免说明。
                    if v.maijia ~= player then
                        num = num + 1
                        tinsert(menu, num + 1, {
                            text = TRADE .. PLAYER,
                            notCheckable = true,
                            disabled = true,
                            arg1 = "auctionLogTrade",
                            arg2 = v.maijia,
                            func = function()
                                InitiateTrade(v.maijia)
                            end
                        })
                        num = num + 1
                        tinsert(menu, num + 1, {
                            text = FOLLOW .. PLAYER,
                            notCheckable = true,
                            disabled = true,
                            arg1 = "auctionLogFollow",
                            arg2 = v.maijia,
                            func = function()
                                FollowUnit(v.maijia)
                            end
                        })
                        num = num + 1
                        tinsert(menu, num + 1, {
                            isTitle = true,
                            text = "   ",
                            notCheckable = true,
                        })
                    end
                elseif v.type == 2 then
                    -- 流拍
                    if not BG.IsML and IsInRaid(1) then
                        menu[2].text = L['|cff%s向团长申请重拍|r']:format(BG.TargetVerOver(BG.GetMLName(), 20000) and tonumber(v.jine)
                            and 'ffffff' or '808080')
                        menu[2].disabled = not (tonumber(v.jine))
                        menu[2].func = function()
                            if GetTime() - reAuctionSendCD > 3 then
                                C_ChatInfo.SendAddonMessage("BiaoGe", format("ReAuction^%s^%s^%s", GetItemID(link), link, v.jine), "RAID")
                                BG.SendSystemMessage(L["已向团长发送重拍申请："] .. link)
                                reAuctionSendCD = GetTime()
                            else
                                BG.SendSystemMessage(L["申请太频繁了，等待3秒后再尝试。"])
                            end
                        end
                        menu[2].tooltipTitle = L['向团长申请重拍']
                        menu[2].tooltipText = L['团长的BGLite版本高于%s时才能收到你的请求。']:format('v2.0.0')
                        menu[2].tooltipOnButton = true
                    end
                    menu[3].text = L["设为成功拍卖"]
                    menu[3].arg1 = menu[3].text
                    tinsert(menu, 2, {
                        text = L["|cff808080流拍价："] .. (v.jine and BG.FormatNumber(v.jine, 2) or UNKNOWN),
                        isTitle = true,
                        notCheckable = true,
                    })
                    tinsert(menu, 3, {
                        isTitle = true,
                        text = "   ",
                        notCheckable = true,
                    })
                end
            end
            return menu
        end

        -- 实时刷新「交易玩家」「跟随玩家」两个按钮的可用状态。
        -- 菜单项创建时是 disabled = true，这里按暴雪自身的可用性规则启用：
        -- 交易需在交互距离 2 内、跟随需在距离 4 内，且都要求不处于战斗中。
        _G["L_DropDownList1"]:HookScript("OnUpdate", function(self)
            if L_DropDownList1.dropdown ~= dropDown then return end
            for i = 1, _G['L_DropDownList1'].numButtons do
                local button = _G["L_DropDownList1Button" .. i]
                if button.arg1 == "auctionLogTrade" then
                    if not InCombatLockdown() and CheckInteractDistance(button.arg2, 2) then
                        button:Enable()
                    else
                        button:Disable()
                    end
                elseif button.arg1 == "auctionLogFollow" then
                    if not InCombatLockdown() and CheckInteractDistance(button.arg2, 4) then
                        button:Enable()
                    else
                        button:Disable()
                    end
                end
            end
        end)
    end

    -- 列表内容
    local CreateButton
    do
        function CancelAllChoose()
            wipe(BG.auctionLogFrame.choosed)
            BG.UpdateAuctionLogFrame(true, true)
        end

        local function IsCanChooseList()
            return BiaoGe.options.auctionLogChoose == 3 or BiaoGe.options.auctionLogChoose == 4
        end

        local function CancelChoose(bt)
            bt.ischoose = nil
            if bt.num % 2 == 0 then
                bt.tex:SetColorTexture(.5, .5, .5, .15)
            else
                bt.tex:SetColorTexture(0, 0, 0, .25)
            end
        end
        local function OnMouseUp(f, button)
            local v = f.v
            local index = f.index
            local notAuctioned = f.notAuctioned
            local link = f.link
            local itemID = f.itemID
            local icon = f.icon
            local bts = f.bts
            local num = f.num
            if button == "RightButton" and not IsAltKeyDown() then
                wipe(BG.auctionLogFrame.choosed)
                lastChoose = num
                for _i, bt in ipairs(BG.auctionLogFrame.buttons) do
                    CancelChoose(bt)
                end
                local menu = CreateMenu(f, index, v, notAuctioned, link, icon)
                if menu then
                    LibBG:EasyMenu(menu, dropDown, "cursor", 10, 10, "MENU", 2)
                    BG.PlaySound(1)
                end
                if IsCanChooseList() then
                    UpdateButtonStartAuction()
                end
                return
            end
            -- 已移除「设为最佳价格」分支（第三方付费模块 BGV 提供的能力）
            if IsAltKeyDown() and BG.IsML then
                if v.type == 1 or v.type == 2 then
                    AddNeedDeleteItem(index, v)
                end
                if IsCanChooseList() then
                    wipe(BG.auctionLogFrame.choosed)
                    for _i, bt in ipairs(BG.auctionLogFrame.buttons) do
                        CancelChoose(bt)
                    end
                    UpdateButtonStartAuction()
                end
                BG.StartAuction(link, f, true, nil, button == "RightButton", nil, (v.type == 1 or v.type == 2) and DeleteLiuPaiAuctionLog)
                return
            end
            if IsCanChooseList() then
                BG.PlaySound(1)
                if IsControlKeyDown() then
                    bts.ischoose = not bts.ischoose
                    if bts.ischoose then
                        if #BG.auctionLogFrame.choosed < 5 then
                            tinsert(BG.auctionLogFrame.choosed, { id = itemID, link = link, money = v.jine, index = index })
                            bts.tex:SetColorTexture(1, 1, 0, .5)
                        else
                            bts.ischoose = nil
                        end
                        lastChoose = num
                    else
                        for _i = #BG.auctionLogFrame.choosed, 1, -1 do
                            if BG.auctionLogFrame.choosed[_i].id == itemID then
                                tremove(BG.auctionLogFrame.choosed, _i)
                                break
                            end
                        end
                        CancelChoose(bts)
                    end
                elseif IsShiftKeyDown() then
                    if #BG.auctionLogFrame.choosed == 0 then
                        BG.InsertLink(link)
                    elseif lastChoose then
                        for _i, bt in ipairs(BG.auctionLogFrame.buttons) do
                            if _i ~= index then
                                CancelChoose(bt)
                            end
                        end
                        wipe(BG.auctionLogFrame.choosed)

                        local count = 0
                        for _i = lastChoose, num, lastChoose < num and 1 or -1 do
                            if count < 5 then
                                local bt = BG.auctionLogFrame.buttons[_i]
                                bt.ischoose = true
                                tinsert(BG.auctionLogFrame.choosed, { id = bt.itemID, link = bt.link, money = bt.jine, index = bt.index })
                                bt.tex:SetColorTexture(1, 1, 0, .5)
                                count = count + 1
                            end
                        end
                        lastChoose = nil
                    end
                else
                    BG.PlaySound(1)

                    for _i, bt in ipairs(BG.auctionLogFrame.buttons) do
                        if _i ~= num then
                            CancelChoose(bt)
                        end
                    end
                    wipe(BG.auctionLogFrame.choosed)

                    bts.ischoose = not bts.ischoose
                    if bts.ischoose then
                        tinsert(BG.auctionLogFrame.choosed, { id = itemID, link = link, money = v.jine, index = index })
                        bts.tex:SetColorTexture(1, 1, 0, .5)
                        lastChoose = num
                    else
                        for _i = #BG.auctionLogFrame.choosed, 1, -1 do
                            if BG.auctionLogFrame.choosed[_i].id == itemID then
                                tremove(BG.auctionLogFrame.choosed, _i)
                            end
                        end
                        CancelChoose(bts)
                    end
                end
                LibBG:CloseDropDownMenus()
            else
                if IsShiftKeyDown() then
                    BG.PlaySound(1)
                    BG.InsertLink(link)
                end
            end
            if IsCanChooseList() then
                UpdateButtonStartAuction()
            end
        end
        local function OnMouseDown(f, button)
            if not IsCanChooseList() then return end
            local x, y = GetCursorPosition()
            local scale = UIParent:GetEffectiveScale()
            x, y = x / scale, y / scale
            drag.startX, drag.startY = x, y
        end
        local function DragOnUpdate(self)
            if not IsCanChooseList() then return end
            local x, y = GetCursorPosition()
            local scale = UIParent:GetEffectiveScale()
            x, y = x / scale, y / scale
            drag.frame:ClearAllPoints()
            local left = min(x, drag.startX)
            local right = max(x, drag.startX)
            local top = max(y, drag.startY)
            local bottom = min(y, drag.startY)
            drag.frame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left, top)
            drag.frame:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMLEFT", right, bottom)

            -- 实时框选：矩形相交判断
            for _, bt in ipairs(BG.auctionLogFrame.buttons) do
                local f = bt.frame
                if f:IsVisible() then
                    local bLeft, bRight = f:GetLeft(), f:GetRight()
                    local bTop, bBottom = f:GetTop(), f:GetBottom()
                    if bLeft and bRight then
                        if bLeft < right and bRight > left and bTop > bottom and bBottom < top then
                            if not bt.ischoose and #BG.auctionLogFrame.choosed < 5 then
                                bt.ischoose = true
                                tinsert(BG.auctionLogFrame.choosed, { id = bt.itemID, link = bt.link, money = bt.jine, index = bt.index })
                                bt.tex:SetColorTexture(1, 1, 0, .5)
                                lastChoose = bt.num
                            end
                        end
                    end
                end
            end
            UpdateButtonStartAuction()
        end
        local function OnDragStart(self)
            if not IsCanChooseList() then return end
            -- 先取消所有已选
            for _i, bt in ipairs(BG.auctionLogFrame.buttons) do
                CancelChoose(bt)
            end
            wipe(BG.auctionLogFrame.choosed)
            UpdateButtonStartAuction()
            LibBG:CloseDropDownMenus()
            local f = CreateFrame("Frame", nil, BG.auctionLogFrame, "BackdropTemplate")
            f:SetBackdrop({
                edgeFile = "Interface/ChatFrame/ChatFrameBackground",
                edgeSize = 1.5,
            })
            f:SetBackdropBorderColor(0, 1, 0, 1)
            f:SetFrameLevel(BG.auctionLogFrame:GetFrameLevel() + 10)
            drag.frame = f
            BG.auctionLogFrame:SetScript('OnUpdate', DragOnUpdate)
        end
        local function OnDragStop(self)
            if not drag.frame then return end
            drag.frame:Hide()
            BG.auctionLogFrame:SetScript('OnUpdate', nil)
        end

        child:SetScript("OnMouseDown", OnMouseDown)
        child:SetScript("OnDragStart", OnDragStart)
        child:SetScript("OnDragStop", OnDragStop)

        function CreateButton(index, v, num)
            local bts = {}
            local width = child:GetWidth()
            local link = v.zhuangbei
            local itemID = GetItemID(link)
            local icon, typeID = select(5, GetItemInfoInstant(link))
            local r, g, b = GetItemQualityColor(v.quality)
            local notAuctioned = v.type == 3
            bts.link = link
            bts.itemID = itemID
            bts.num = num
            bts.jine = v.jine
            bts.index = index

            -- 主框架
            do
                local f = CreateFrame("Frame", nil, child, "BackdropTemplate")
                f:SetSize(width, 32)
                if #BG.auctionLogFrame.buttons == 0 then
                    f:SetPoint("TOPLEFT")
                else
                    f:SetPoint("TOPLEFT", BG.auctionLogFrame.buttons[#BG.auctionLogFrame.buttons].frame, "BOTTOMLEFT", 0, 0)
                end
                f:Show()
                f:RegisterForDrag("LeftButton")
                f.link = link
                f.index = index
                f.v = v
                f.num = num
                f.link = link
                f.itemID = itemID
                f.icon = icon
                f.typeID = typeID
                f.bts = bts
                f.jine = v.jine
                f.notAuctioned = notAuctioned
                bts.frame = f
                f:SetScript("OnMouseUp", OnMouseUp)
                f:SetScript("OnMouseDown", OnMouseDown)
                f:SetScript("OnDragStart", OnDragStart)
                f:SetScript("OnDragStop", OnDragStop)
                BG.OnEnterDelay(f, function(self)
                    GameTooltip:SetOwner(frame.tooltip, "ANCHOR_BOTTOMRIGHT", 0, 0)
                    GameTooltip:ClearLines()
                    local itemID = GetItemInfoInstant(link)
                    if itemID then
                        if not BG.IsHideTooltipKeyDown() then
                            GameTooltip:SetHyperlink(BG.SetSpecIDToLink(link))
                            GameTooltip:AddLine(L['< 按住CTRL+SHIFT隐藏此界面 >'], 0, 1, 0, true)
                            GameTooltip:Show()
                            BG.SetZUGSetTooltip(itemID, 'RIGHT')
                        end
                        BG.Show_AllHighlight(link, "auctionlog")
                        HighlightBiaoGeSameItems(itemID, link, self)
                        if IsAltKeyDown() and BG.IsML and BiaoGe.options["autoAuctionStart"] == 1 then
                            SetCursor("interface/cursor/repair")
                        elseif IsControlKeyDown() or IsShiftKeyDown() then
                            SetCursor(nil)
                        end
                        if BG.IsML then
                            BG.canShowStartAuctionCursor = true
                        end
                        BG.DressUpLastButton = self
                    end
                    bts.ds:Show()
                end, BG.itemOnEnterDelay)
                BG.OnLeaveDelay(f, function(self)
                    GameTooltip:Hide()
                    BG.Hide_AllHighlight()
                    bts.ds:Hide()
                    SetCursor(nil)
                    BG.canShowStartAuctionCursor = false
                    if BG.DressUpFrame then
                        BG.DressUpFrame:Hide()
                    end
                    BG.DressUpLastButton = nil
                end)

                local tex = bts.frame:CreateTexture(nil, "BACKGROUND")
                tex:SetAllPoints()
                if num % 2 == 0 then
                    tex:SetColorTexture(.5, .5, .5, .15)
                else
                    tex:SetColorTexture(0, 0, 0, .25)
                end
                bts.tex = tex

                local tex = bts.frame:CreateTexture()
                tex:SetAllPoints()
                tex:SetColorTexture(.5, .5, .5, .5)
                tex:Hide()
                bts.ds = tex

                tinsert(BG.auctionLogFrame.buttons, bts)

            end
            -- 图标和装等
            do
                local f = CreateFrame("Frame", nil, bts.frame, "BackdropTemplate")
                f:SetBackdrop({
                    edgeFile = "Interface/ChatFrame/ChatFrameBackground",
                    edgeSize = 1,
                })
                f:SetBackdropBorderColor(r, g, b)
                f:SetSize(bts.frame:GetHeight() - 2, bts.frame:GetHeight() - 2)
                f:SetPoint("LEFT")
                bts.iconFrame = f
                local tex = f:CreateTexture(nil, "BACKGROUND")
                tex:SetAllPoints()
                tex:SetTexture(icon)
                tex:SetTexCoord(unpack(BG.iconTexCoord))
                bts.icon = tex
                f.level = f:CreateFontString()
                f.level:SetFont(BIAOGE_TEXT_FONT, 11, "OUTLINE")
                f.level:SetPoint("BOTTOM", bts.icon, 0, 1)
                f.level:SetText((typeID == 2 or typeID == 4) and v.itemlevel or nil)
                f.level:SetTextColor(r, g, b)
                if v.bindType == 2 then
                    local text = bts.iconFrame:CreateFontString()
                    text:SetFont(BIAOGE_TEXT_FONT, 10, "OUTLINE")
                    text:SetPoint("TOP", bts.iconFrame, 0, -1)
                    text:SetText(L["装绑"])
                    text:SetTextColor(0, 1, 0)
                end
            end
            -- 装备
            do
                local text = bts.frame:CreateFontString()
                text:SetFont(BIAOGE_TEXT_FONT, 14, "OUTLINE")
                text:SetWidth(width - bts.icon:GetWidth())
                text:SetPoint("TOPLEFT", bts.icon, "TOPRIGHT", 1, 0)
                text:SetText(link:gsub("%[", ""):gsub("%]", ""))
                text:SetJustifyH("LEFT")
                text:SetWordWrap(false)
                bts.item = text
            end
            -- 买家和金额
            do
                local text = bts.frame:CreateFontString()
                text:SetFont(BIAOGE_TEXT_FONT, 14, "OUTLINE")
                text:SetPoint("BOTTOMLEFT", bts.icon, "BOTTOMRIGHT", 1, 0)
                text:SetWidth(width - bts.icon:GetWidth())
                text.notAuctionedText = BG.STC_dis(L["<未拍>"])
                text.LiuPaiText = BG.STC_r1(L["<流拍>"])
                text.auctionText = BG.STC_y1(L["<正在拍卖>"])
                if v.type == 1 then
                    local color = "FFFFFF"
                    if v.color then
                        local r, g, b = unpack(v.color)
                        color = RGB_16(nil, r, g, b)
                    end
                    text:SetText(format("%s |cff%s%s|r", BG.FormatNumber(v.jine, 2), color, v.maijia))
                elseif notAuctioned then
                    text:SetText(text.notAuctionedText)
                else
                    text:SetText(text.LiuPaiText)
                end
                text:SetJustifyH("LEFT")
                text:SetWordWrap(false)
                bts.money = text
            end
            -- 已拍未交易
            if v.type == 1 and v.trade then
                local text = bts.frame:CreateFontString(nil, "OVERLAY")
                text:SetFont(BIAOGE_TEXT_FONT, 14, "OUTLINE")
                text:SetPoint("TOPRIGHT", -1, -1)
                text:SetText(L["已交易"])
                text:SetTextColor(0, 1, 0)
            end

            -- The row is complete now, so the filter can update both the row
            -- alpha and the equipment icon/name without racing their creation.
            bts.qualityColor = { r, g, b }
            bts.frame.gearScoreListButton = bts
            BG.UpdateFilter(bts.frame, link)
        end
    end

    local function SearchText(v)
        local searchText = BG.auctionLogFrame.serachEdit:GetText()
        if searchText == "" then
            return true
        end
        if v.zhuangbei and v.zhuangbei:match("%[.+%]"):find(searchText, 1, true) then
            return true
        end
        if v.maijia and v.maijia:find(searchText, 1, true) then
            return true
        end
        if v.jine and v.jine == searchText then
            return true
        end
    end

    local function UpdateFrameSize()
        BG.auctionLogFrame:SetHeight(BG.FBHeight[BG.FB1])
        child:SetHeight(scroll:GetHeight())
    end

    local playerInfo = BiaoGe.playerInfo[RealmID]
    local function IsMyPlayer(player)
        return playerInfo[player]
    end

    function BG.UpdateAuctionLogFrame(notSetDown, notSetUp)
        if BG.auctionLogFrame:IsVisible() then
            UpdateFrameSize()
            for i, v in ipairs(BG.auctionLogFrame.buttons) do
                v.frame:Hide()
                v.frame:SetParent(nil)
            end
            wipe(BG.auctionLogFrame.buttons)
            BG.auctionLogFrame.notText:Hide()
            if not notSetUp then
                wipe(BG.auctionLogFrame.choosed)
                lastChoose = nil
            end
            UpdateButtonStartAuction()

            local FB = BG.FB1
            local sum = 0
            local tbl = BiaoGe[FB].auctionLog
            local notCache = 0
            if not tbl or #tbl == 0 then
                BG.auctionLogFrame.ButtonCreateLedger:Disable()
                BG.auctionLogFrame.ButtonCreateDuiZhang:Disable()
                if BiaoGe.options.auctionLogChoose ~= 4 then
                    BG.auctionLogFrame.notText:Show()
                end
            else
                BG.auctionLogFrame.ButtonCreateLedger:Enable()
                BG.auctionLogFrame.ButtonCreateDuiZhang:Enable()
            end
            BG.auctionLogFrame.ButtonAdd:Enable()
            BG.auctionLogFrame.title:SetText(L["自动拍卖记录"])
            BG.auctionLogFrame.title:SetTextColor(1, 1, 1)
            if tbl then
                local num = 0
                for i, v in ipairs(tbl) do
                    -- type 1：成功 2：流拍
                    if (
                            BiaoGe.options.auctionLogChoose == 1
                            or (BiaoGe.options.auctionLogChoose == 2 and v.type == 1)
                            or (BiaoGe.options.auctionLogChoose == 3 and v.type == 2)
                            or (BiaoGe.options.auctionLogChoose == 5 and not v.trade and v.type == 1)
                            or (BiaoGe.options.auctionLogChoose == 6 and v.type == 1 and IsMyPlayer(v.maijia))
                        )
                        and SearchText(v)
                    then
                        num = num + 1
                        CreateButton(i, v, num)
                    end
                    if v.type == 1 then
                        sum = sum + (tonumber(v.jine) or 0)
                    end
                end
                if BiaoGe.options.auctionLogChoose == 7 then
                    local errorTbl = GetErrorItem(tbl, true)
                    if errorTbl then
                        for _, vv in ipairs(errorTbl) do
                            for i, v in ipairs(vv.info) do
                                num = num + 1
                                local index = vv.indexs[i]
                                CreateButton(index, v, num)
                            end
                        end
                    end
                end
            end

            if BiaoGe.options.auctionLogChoose == 4 then
                local newTbl = {}
                for b = 1, Maxb[FB] do
                    for i = 1, BG.GetMaxi(FB, b) do
                        if BG.Frame[FB]["boss" .. b]["zhuangbei" .. i] then
                            local zb = BiaoGe[FB]["boss" .. b]["zhuangbei" .. i]
                            if GetItemID(zb) then
                                tinsert(newTbl, zb)
                            end
                        end
                    end
                end
                if tbl then
                    local copyTbl = BG.Copy(tbl)
                    for i = #newTbl, 1, -1 do
                        for _i = #copyTbl, 1, -1 do
                            if GetItemID(newTbl[i]) == GetItemID(copyTbl[_i].zhuangbei) then
                                tremove(newTbl, i)
                                tremove(copyTbl, _i)
                                break
                            end
                        end
                    end
                end
                for i, zhuangbei in ipairs(newTbl) do
                    local item = Item:CreateFromItemID(GetItemID(zhuangbei))
                    if not GetItemInfo(zhuangbei) then
                        notCache = 0.5
                    end
                    item:ContinueOnItemLoad(function()
                        local name, link, quality, level, _, _, _, _, EquipLoc, Texture,
                        _, typeID, subclassID, bindType = GetItemInfo(zhuangbei)
                        newTbl[i] = {
                            type = 3,
                            zhuangbei = zhuangbei,
                            itemlevel = level,
                            quality = quality,
                            bindType = bindType,
                        }
                    end)
                end

                local function Create()
                    for i, bt in ipairs(BG.auctionLogFrame.buttons) do
                        bt.frame:Hide()
                    end
                    wipe(BG.auctionLogFrame.buttons)

                    for i, v in ipairs(newTbl) do
                        if SearchText(v) then
                            CreateButton(i, v, i)
                        end
                    end
                    BG.UpdateAuctioning()

                    for i, v in ipairs(BG.auctionLogFrame.choosed) do
                        local itemID = v.id
                        for i, bt in ipairs(BG.auctionLogFrame.buttons) do
                            if bt.itemID == itemID then
                                bt.ischoose = true
                                bt.tex:Show()
                                bt.tex:SetColorTexture(1, 1, 0, .5)
                                break
                            end
                        end
                    end
                end
                if notCache == 0 then
                    Create()
                else
                    BG.After(notCache, function()
                        Create()
                    end)
                end
            end

            BG.auctionLogFrame.sumText:SetText(L["合计收入："] .. BG.FormatNumber(sum, 2))

            if BiaoGe.options.auctionLogChoose == 4 then
                if not notSetUp then
                    BG.After(notCache + 0.05, function()
                        local min, max = frame.scroll.ScrollBar:GetMinMaxValues()
                        frame.scroll.ScrollBar:SetValue(min)
                    end)
                end
            elseif not notSetDown then
                BG.After(0, function()
                    local min, max = frame.scroll.ScrollBar:GetMinMaxValues()
                    frame.scroll.ScrollBar:SetValue(max)
                end)
            end
        end
        if BG.UpdateLootAuctionLogFrame then
            BG.UpdateLootAuctionLogFrame()
        end
    end

    function BG.UpdateAuctioning()
        if BiaoGe.options.auctionLogChoose == 4 then
            local auctioning = BG.Copy(BG.auctionLogFrame.auctioning)
            for _, bt in ipairs(BG.auctionLogFrame.buttons) do
                bt.money:SetText(bt.money.notAuctionedText)
                for i = #auctioning, 1, -1 do
                    if bt.itemID == auctioning[i] then
                        bt.money:SetText(bt.money.auctionText)
                        tremove(auctioning, i)
                        break
                    end
                end
            end
        end
    end

    BG.auctionLogFrame.serachEdit:HookScript("OnTextChanged", BG.UpdateAuctionLogFrame)

    -- 记录自动拍卖结果
    do
        local function DeleteAuctioning(itemID)
            for i = #BG.auctionLogFrame.auctioning, 1, -1 do
                if BG.auctionLogFrame.auctioning[i] == itemID then
                    tremove(BG.auctionLogFrame.auctioning, i)
                    break
                end
            end
        end
        function BG.GetTargetAuctionTradeItems(tradeName)
            local FB = BG.FB1
            BG.auctionTrade[tradeName] = {}
            for _, v in ipairs(BiaoGe[FB].auctionLog or {}) do
                if v.type == 1 and not v.trade and v.maijia == tradeName then
                    tinsert(BG.auctionTrade[tradeName], BG.Copy(v))
                end
            end
        end

        local function MoneyIsError(money)
            return money:match("[!@#$%^&*]")
        end

        local function GetFB(itemID)
            if BG.FB2 then return BG.FB2 end
            local FBs = { BG.FB1 }
            for i = #BG.FBtable, 1, -1 do
                local FB = BG.FBtable[i]
                if FB ~= BG.FB1 then
                    tinsert(FBs, FB)
                end
            end
            local returnFB
            for _, FB in ipairs(FBs) do
                BG.PairFBItem(function(item)
                    local str = item:GetText()
                    if str ~= '' and GetItemID(str) == itemID then
                        returnFB = FB
                        return true
                    end
                end, nil, nil, FB)
                if returnFB then
                    return returnFB
                end
            end
            return BG.FB1
        end

        function BG.AuctionWAEnd(endType, zhuangbei, maijia, jine, logs)
            if endType == 1 and zhuangbei and maijia and jine then -- 成功
                jine = tostring(jine)
                local itemID = GetItemID(zhuangbei)
                DeleteAuctioning(itemID)
                local item = Item:CreateFromItemID(itemID)
                item:ContinueOnItemLoad(function()
                    local name, link, quality, level, _, _, _, _, EquipLoc, Texture,
                    _, typeID, subclassID, bindType = GetItemInfo(zhuangbei)
                    local FB = GetFB(itemID)
                    local log
                    if next(logs) then
                        log = {}
                        local num = 1
                        local yes = true
                        for i = #logs, 1, -1 do
                            if not yes and num > 5 then break end
                            num = num + 1
                            local a = BG.Copy(logs[i])
                            a.i = i
                            tinsert(log, 1, a)
                        end
                        if MoneyIsError(jine) and logs[#logs] then
                            jine = tostring(logs[#logs].money)
                        end
                    end

                    local playerClass = {}
                    for k, v in pairs(BG.playerClass) do
                        local value = select(v.select, v.func(maijia))
                        if value == 0 then value = nil end
                        playerClass[k] = value
                    end
                    if not playerClass.guild then
                        playerClass.realm = nil
                    end
                    local a = {
                        type = 1,
                        time = time(),
                        zhuangbei = zhuangbei,
                        maijia = maijia,
                        jine = jine,
                        itemlevel = level,
                        quality = quality,
                        bindType = bindType,
                        log = log,
                        trade = BG.ImML() and maijia == BG.playerName or nil,
                    }
                    for k, v in pairs(playerClass) do
                        a[k] = v
                    end
                    BiaoGe[FB].auctionLog = BiaoGe[FB].auctionLog or {}
                    tinsert(BiaoGe[FB].auctionLog, a)
                    BG.UpdateAuctionLogFrame(nil, true)

                    local tradeName = BG.GN("NPC")
                    if BG.tradelastAuctionFrame.frame:IsVisible() and tradeName and maijia == tradeName then
                        BG.GetTargetAuctionTradeItems(maijia)
                        if BG.ImMLorLeader() then
                            BG.tradelastAuctionFrame.UpdateChooseType()
                            BG.tradelastAuctionFrame.UpdateAutoButtons()
                        end
                    end

                    BG.SaveRLAuction(zhuangbei, maijia, jine, FB)

                    if BG.IsAutoCreateBill() then
                        BG.After(0.1, function()
                            BG.CreateBillByAuctionLog(FB)
                        end)
                    end
                end)
                return
            elseif endType == 2 and zhuangbei then -- 流拍
                local itemID = GetItemID(zhuangbei)
                DeleteAuctioning(itemID)
                local item = Item:CreateFromItemID(itemID)
                item:ContinueOnItemLoad(function()
                    local name, link, quality, level, _, _, _, _, EquipLoc, Texture,
                    _, typeID, subclassID, bindType = GetItemInfo(zhuangbei)
                    local FB = GetFB(itemID)
                    local a = {
                        type = 2,
                        time = time(),
                        zhuangbei = zhuangbei,
                        jine = tonumber(jine) or 0,
                        itemlevel = level,
                        quality = quality,
                        bindType = bindType,
                    }
                    BiaoGe[FB].auctionLog = BiaoGe[FB].auctionLog or {}
                    tinsert(BiaoGe[FB].auctionLog, a)
                    BG.UpdateAuctionLogFrame(nil, true)
                end)
                return
            elseif endType == 3 and zhuangbei then -- 取消
                DeleteAuctioning(GetItemID(zhuangbei))
                BG.UpdateAuctioning()
            end
        end
    end

    -- 拍卖成功的聊天信息后面附上出价记录
    do
        ChatFrame_AddMessageEventFilter("CHAT_MSG_RAID_LEADER", function(self, event, msg, ...)
            if BiaoGe.options.autoAuctionLogLink ~= 1 then return end
            if not (msg:match("{rt6}拍卖成功{rt6}") or msg:match("{rt6}拍賣成功{rt6}") or msg:match("{rt6}Auction Successful{rt6}")) then return end
            local itemID = GetItemID(msg)
            if not itemID then return end
            BG.chatAuctionLog = BG.chatAuctionLog or {}
            local FB = BG.FB2 or BG.FB1
            local log
            if BiaoGe[FB].auctionLog and next(BiaoGe[FB].auctionLog) then
                local info = BiaoGe[FB].auctionLog[#BiaoGe[FB].auctionLog]
                if GetItemID(info.zhuangbei) == itemID and info.log then
                    log = BG.Copy(info.log)
                end
            end
            if not log then return end
            tinsert(BG.chatAuctionLog, log)
            local link = "|cffFFFF00" .. "|Hgarrmission:BiaoGe:AuctionWALog:" .. itemID .. ":"
                .. #BG.chatAuctionLog .. "|h[" .. L["记录"] .. "]|h|r"
            local newmsg = msg .. link
            return false, newmsg, ...
        end)
        local function OnHyperlinkEnter(self, link)
            if not link then return end
            local _, arg2, arg3, itemID, num = strsplit(":", link)
            if arg2 == "BiaoGe" and arg3 == "AuctionWALog" and num then
                itemID = tonumber(itemID)
                num = tonumber(num)
                local _, link = GetItemInfo(itemID)
                if not link then return end
                GameTooltip:SetOwner(self, "ANCHOR_TOPRIGHT", 0, 0)
                GameTooltip:ClearLines()
                GameTooltip:AddLine(link:gsub("%[", ""):gsub("%]", ""), 1, 1, 1, true)
                if BG.chatAuctionLog[num][1] and BG.chatAuctionLog[num][1].i ~= 1 then
                    GameTooltip:AddLine("......", .5, .5, .5, true)
                end
                for i, v in ipairs(BG.chatAuctionLog[num]) do
                    GameTooltip:AddLine(AddLogLine(v), 1, .82, 0)
                end
                GameTooltip:Show()
            end
        end
        local i = 1
        while _G["ChatFrame" .. i] do
            _G["ChatFrame" .. i]:HookScript("OnHyperlinkEnter", OnHyperlinkEnter)
            _G["ChatFrame" .. i]:HookScript("OnHyperlinkLeave", GameTooltip_Hide)
            i = i + 1
        end
        local lastNum
        hooksecurefunc("SetItemRef", function(link, text, button)
            if not link then return end
            local _, arg2, arg3, itemID, num = strsplit(":", link)
            if arg2 == "BiaoGe" and arg3 == "AuctionWALog" and num then
                itemID = tonumber(itemID)
                num = tonumber(num)
                local _, link = GetItemInfo(itemID)
                if not link then return end
                if ItemRefTooltip:IsVisible() and num == lastNum then
                    lastNum = nil
                    ItemRefTooltip:Hide()
                    return
                end
                ItemRefTooltip:SetOwner(UIParent, "ANCHOR_PRESERVE")
                ItemRefTooltip:ClearLines()
                ItemRefTooltip:AddLine(link:gsub("%[", ""):gsub("%]", ""), 1, 1, 1, true)
                if BG.chatAuctionLog[num][1] and BG.chatAuctionLog[num][1].i ~= 1 then
                    ItemRefTooltip:AddLine("......", .5, .5, .5, true)
                end
                for i, v in ipairs(BG.chatAuctionLog[num]) do
                    ItemRefTooltip:AddLine(v.i .. L["、"] .. v.money .. format(L["（%s）"], v.player), 1, .82, 0)
                end
                ItemRefTooltip:Show()
                lastNum = num
            else
                lastNum = nil
            end
        end)
    end

    -- 团员申请重拍
    do
        local reAuctionCD = {}
        local name = "BiaoGe_ReAuctionRequest"
        StaticPopupDialogs[name] = {
            text = " ",
            button1 = L["重拍"],
            button2 = CANCEL,
            OnShow = function(self)
                local info = BG.pendingReAuction
                local text = self.Text or self.text
                local icon = select(5, GetItemInfoInstant(info.itemID))
                text:SetText(L['%s 向你申请重拍流拍装备：\n\n%s%s（流拍价：%s）\n\n是否重拍该装备？']:format(
                    SetClassCFF(info.sender), AddTexture(icon), info.link, info.money
                ))
                self:SetHyperlinksEnabled(true)
                self:SetScript("OnHyperlinkEnter", function(self, link, text, button)
                    local itemID = GetItemID(link)
                    if itemID then
                        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM", 0, 0)
                        GameTooltip:ClearLines()
                        GameTooltip:SetHyperlink(BG.SetSpecIDToLink(link))
                    end
                end)
                self:SetScript("OnHyperlinkLeave", GameTooltip_Hide)
            end,
            OnAccept = function()
                local info = BG.pendingReAuction
                if info then
                    local isGen2 = BiaoGe.Auction.gen == 2
                    local mod = BiaoGe.Auction.mod
                    local resetThreshold = max(tonumber(BiaoGe.Auction.resetThreshold) or 0, 10)
                    BG.SendStartAuctionMsg(isGen2, info.itemID, info.money, 20, mod, info.link, resetThreshold)
                    local FB = BG.FB2 or BG.FB1
                    if BiaoGe[FB].auctionLog then
                        for i, v in ipairs(BiaoGe[FB].auctionLog) do
                            if v.type == 2 and BG.IsSameItem(v.zhuangbei, info.link) then
                                BG.SendSystemMessage(L['%s的拍卖记录已被改为正在拍卖。']:format(v.zhuangbei))
                                tremove(BiaoGe[FB].auctionLog, i)
                                BG.UpdateAuctionLogFrame(nil, true)
                                break
                            end
                        end
                    end
                end
            end,
            OnCancel = function()
            end,
            timeout = 0,
            whileDead = true,
            hideOnEscape = true,
            showAlert = true,
        }
        BG.RegisterEvent("CHAT_MSG_ADDON", function(self, event, prefix, msg, distType, _, sender)
            if prefix ~= "BiaoGe" or distType ~= "RAID" then return end
            local cmd, itemID, link, money = strsplit("^", msg)
            if cmd ~= "ReAuction" then return end
            if not BG.ImML() then return end
            if GetTime() - (reAuctionCD[sender] or 0) > 3 then
                reAuctionCD[sender] = GetTime()
                itemID = tonumber(itemID)
                if not itemID then return end
                if not GetItemID(link) then return end
                money = tonumber(money) or 1
                if money < 1 then
                    money = 1
                end
                BG.SendSystemMessage(L["%s向你申请重拍流拍装备：%s（%s金）。"]:format(SetClassCFF(sender), link, money))
                local FB = BG.FB2 or BG.FB1
                if BiaoGe[FB].auctionLog then
                    for i, v in ipairs(BiaoGe[FB].auctionLog) do
                        if v.type == 2 and GetItemID(v.zhuangbei) == itemID then
                            BG.pendingReAuction = { sender = sender, itemID = itemID, link = link, money = money }
                            StaticPopup_Show(name)
                            return
                        end
                    end
                end
            end
        end)
    end

    -- 团员提醒团长拍卖未拍装备
    do
        local remindAuctionCD = {}
        local name = "BiaoGe_RemindAuctionRequest"
        StaticPopupDialogs[name] = {
            text = " ",
            button1 = L["知道了"],
            OnShow = function(self)
                local info = BG.pendingRemindAuction
                local text = self.Text or self.text
                local icon = select(5, GetItemInfoInstant(info.itemID))
                text:SetText(L['%s 提醒你拍卖未拍装备：\n\n%s%s']:format(
                    SetClassCFF(info.sender), AddTexture(icon), info.link
                ))
                self:SetHyperlinksEnabled(true)
                self:SetScript("OnHyperlinkEnter", function(self, link, text, button)
                    local itemID = GetItemID(link)
                    if itemID then
                        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM", 0, 0)
                        GameTooltip:ClearLines()
                        GameTooltip:SetHyperlink(BG.SetSpecIDToLink(link))
                    end
                end)
                self:SetScript("OnHyperlinkLeave", GameTooltip_Hide)
            end,
            OnAccept = function()
            end,
            timeout = 0,
            whileDead = true,
            hideOnEscape = true,
            showAlert = true,
        }
        BG.RegisterEvent("CHAT_MSG_ADDON", function(self, event, prefix, msg, distType, _, sender)
            if prefix ~= "BiaoGe2" or distType ~= "RAID" then return end
            local cmd, itemID, link = strsplit("^", msg)
            if cmd ~= "RemindAuction" then return end
            if not BG.ImML() then return end
            if GetTime() - (remindAuctionCD[sender] or 0) > 3 then
                remindAuctionCD[sender] = GetTime()
                itemID = tonumber(itemID)
                if not itemID then return end
                if not GetItemID(link) then return end
                BG.SendSystemMessage(L["%s提醒你拍卖未拍装备：%s。"]:format(SetClassCFF(sender), link))
                BG.pendingRemindAuction = { sender = sender, itemID = itemID, link = link }
                StaticPopup_Show(name)
            end
        end)
    end

    -- 团长退货后，团员确认是否把对应拍卖记录设为流拍
    do
        local cd = {}
        local name = "BiaoGe_RefundAuctionToFailed"
        local function FindAuctionLog(itemID, buyer, money)
            local FB = BG.FB2 or BG.FB1
            if not (BiaoGe[FB] and BiaoGe[FB].auctionLog) then return end
            for i, v in ipairs(BiaoGe[FB].auctionLog) do
                if v.type == 1 and BG.IsSame(v.zhuangbei, itemID)
                    and v.maijia == buyer
                    and tostring(v.jine) == tostring(money)
                then
                    return i, v
                end
            end
        end
        StaticPopupDialogs[name] = {
            text = " ",
            button1 = L["是"],
            button2 = L["否"],
            OnShow = function(self)
                local info = BG.pendingRefundAuctionToFailed
                local text = self.Text or self.text
                local icon = select(5, GetItemInfoInstant(info.itemID))
                text:SetText(L['%s%s 广播退货消息：\n\n%s%s\n买家：%s\n退货金额：%s\n\n把该条拍卖记录设为流拍吗？']:format(
                    AddTexture("interface/groupframe/ui-group-leadericon"),
                    SetClassCFF(info.sender),
                    AddTexture(icon),
                    info.link,
                    SetClassCFF(info.buyer),
                    info.money
                ))
                self:SetHyperlinksEnabled(true)
                self:SetScript("OnHyperlinkEnter", function(self, link, text, button)
                    local itemID = GetItemID(link)
                    if itemID then
                        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM", 0, 0)
                        GameTooltip:ClearLines()
                        GameTooltip:SetHyperlink(BG.SetSpecIDToLink(link))
                    end
                end)
                self:SetScript("OnHyperlinkLeave", GameTooltip_Hide)
            end,
            OnAccept = function()
                local info = BG.pendingRefundAuctionToFailed
                if not info then return end
                local _, v = FindAuctionLog(info.itemID, info.buyer, info.money)
                if v then
                    BG.SetAuctionLogItemState(v, 2,true)
                    BG.SendSystemMessage(L['%s的拍卖记录已被改为流拍。']:format(v.zhuangbei))
                end
            end,
            OnCancel = function()
            end,
            timeout = 0,
            whileDead = true,
            hideOnEscape = true,
            showAlert = true,
        }
        BG.RegisterEvent("CHAT_MSG_ADDON", function(self, event, prefix, msg, channel, _, sender)
            if prefix ~= "BiaoGe2" or channel ~= "RAID" then return end
            if sender == player or not BG.IsMLByName(sender) then return end
            local cmd, itemID, link, buyer, money = strsplit("^", msg)
            if cmd ~= "RefundAuctionToFailed" then return end
            if GetTime() - (cd[sender] or 0) > 1 then
                cd[sender] = GetTime()
                itemID = tonumber(itemID)
                if not (itemID and link and buyer and money) then return end
                local _, v = FindAuctionLog(itemID, buyer, money)
                if not v then return end
                BG.pendingRefundAuctionToFailed = {
                    sender = sender,
                    itemID = itemID,
                    link = v.zhuangbei or link,
                    buyer = buyer,
                    money = money,
                }
                StaticPopup_Show(name)
            end
        end)
    end
end)
